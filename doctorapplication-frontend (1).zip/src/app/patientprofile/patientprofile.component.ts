import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patientprofile',
  templateUrl: './patientprofile.component.html',
  styleUrls: ['./patientprofile.component.css']
})
export class PatientprofileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
