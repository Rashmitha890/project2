import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginpatient',
  templateUrl: './loginpatient.component.html',
  styleUrls: ['./loginpatient.component.css']
})
export class LoginpatientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
